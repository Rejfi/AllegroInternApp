package com.example.allegrointernapp.data

data class Offers(
    val offers: List<Offer>
)