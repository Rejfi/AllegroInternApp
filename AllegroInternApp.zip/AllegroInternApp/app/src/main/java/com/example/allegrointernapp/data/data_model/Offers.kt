package com.example.allegrointernapp.data.data_model

import com.example.allegrointernapp.data.data_model.Offer

data class Offers(
    val offers: List<Offer>
)