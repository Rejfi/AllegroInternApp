package com.example.allegrointernapp.network

import okhttp3.Interceptor

interface ConnectivityInterceptor: Interceptor