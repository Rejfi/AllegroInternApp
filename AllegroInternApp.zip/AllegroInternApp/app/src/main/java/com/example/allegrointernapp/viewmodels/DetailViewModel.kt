package com.example.allegrointernapp.viewmodels

import androidx.lifecycle.ViewModel

class DetailViewModel: ViewModel() {


}