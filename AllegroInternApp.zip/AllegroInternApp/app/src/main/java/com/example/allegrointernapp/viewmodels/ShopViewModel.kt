package com.example.allegrointernapp.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.allegrointernapp.data.ShopRepository
import com.example.allegrointernapp.data.Offers
import kotlinx.coroutines.*

class ShopViewModel : ViewModel(){
    private val repository = ShopRepository()
    private var allOffersLiveData = MutableLiveData<Offers>()

    init { setOffers() }

    private fun setOffers() = runBlocking{
        allOffersLiveData.postValue(repository.getAllOffersAsync().await())
    }

    fun getAllOffersLiveData(): LiveData<Offers> {
        return allOffersLiveData
    }

    fun refreshData(){
        setOffers()
    }
}